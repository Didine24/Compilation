Les variables globales:
------------------------:
variable X1 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X2 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X3 DIM:0,TAILLE:0,TYPEF:314valeur 0 
variable X4 DIM:0,TAILLE:0,TYPEF:314valeur 0 
fin d'environnement 

Les fonctions:
------------------------:
fin de liste de fonctions 

Le programme principal:
------------------------:
Se Se Se Af X2 10 Af X4 true Af X1 X2 Af X3 X4 
programme bien type