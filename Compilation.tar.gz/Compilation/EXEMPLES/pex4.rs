analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :2 
trouve X2 en position 0x2531b00 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :3 
trouve X4 en position 0x2531ea0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :0 
trouve X4 en position 0x25322e0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :2 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :1 
trouve X4 en position 0x2532980 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :3 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :2 
trouve X4 en position 0x2533020 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :4 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :2 
trouve X4 en position 0x25336c0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :3 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :1 
trouve X2 en position 0x25340a0 
trouve X4 en position 0x2534350 
trouve X3 en position 0x25344e0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :2 
trouve X4 en position 0x25349c0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :3 
trouve Z en position 0x2534d10 
Les variables globales:
------------------------:
variable X1 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X2 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable Z DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X3 DIM:1,TAILLE:0,TYPEF:314valeur 0 
variable X4 DIM:2,TAILLE:0,TYPEF:314valeur 0 
fin d'environnement 

Les fonctions:
------------------------:
fin de liste de fonctions 

Le programme principal:
------------------------:
Se Se Se Se Se Se Se Af X2 2 Af X4 New_array_of  3 Af Ind X4 0 New_array_of  2 Af Ind X4 1 New_array_of  3 Af Ind X4 2 New_array_of  4 Af Ind Ind X4 2 3 - 0 1 Af X3 Ind X4 X2 Af Z Ind Ind X4 2 3 
erreur de typage