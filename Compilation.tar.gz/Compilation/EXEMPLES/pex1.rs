analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :10 
trouve X2 en position 0x1c4e470 
trouve X2 en position 0x1c4e5b0 
trouve X1 en position 0x1c4e650 
Les variables globales:
------------------------:
variable X1 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X2 DIM:0,TAILLE:0,TYPEF:313valeur 0 
fin d'environnement 

Les fonctions:
------------------------:
fin de liste de fonctions 

Le programme principal:
------------------------:
Se Af X2 10 Af X1 X2 
programme bien type