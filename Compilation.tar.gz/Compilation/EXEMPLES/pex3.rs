analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :5 
trouve X2 en position 0x1387dd0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :6 
trouve X5 en position 0x13881c0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :0 
trouve X5 en position 0x13886a0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :1 
trouve X5 en position 0x1388e00 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :2 
trouve X5 en position 0x1389560 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :3 
trouve X5 en position 0x1389cc0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :4 
trouve X5 en position 0x138a420 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :5 
trouve X5 en position 0x138ab80 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :0 
trouve X5 en position 0x138b330 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :1 
trouve X5 en position 0x138b5e0 
trouve X3 en position 0x138b9a0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :0 
trouve X5 en position 0x138bf70 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :1 
trouve X5 en position 0x138c220 
trouve X4 en position 0x138c860 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :4 
trouve X6 en position 0x138ce30 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :0 
trouve X6 en position 0x138d310 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :10 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :1 
trouve X6 en position 0x138da70 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :11 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :2 
trouve X6 en position 0x138e1d0 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :12 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :3 
trouve X6 en position 0x138e930 
analyse lex, token I,l1 
analyse lex,token I,l2 
analyse lex, ETIQ :13 
Les variables globales:
------------------------:
variable X1 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X2 DIM:0,TAILLE:0,TYPEF:313valeur 0 
variable X3 DIM:0,TAILLE:0,TYPEF:314valeur 0 
variable X4 DIM:0,TAILLE:0,TYPEF:314valeur 0 
variable X5 DIM:1,TAILLE:0,TYPEF:314valeur 0 
variable X6 DIM:1,TAILLE:0,TYPEF:313valeur 0 
fin d'environnement 

Les fonctions:
------------------------:
fin de liste de fonctions 

Le programme principal:
------------------------:
Se Se Se Se Se Se Se Se Se Se Se Se Se Se Af X2 5 Af X5 New_array_of  6 Af Ind X5 0 true Af Ind X5 1 false Af Ind X5 2 true Af Ind X5 3 false Af Ind X5 4 true Af Ind X5 5 false Af X3 Or Ind X5 0 Ind X5 1 Af X4 Not And Ind X5 0 Ind X5 1 Af X6 New_array_of  4 Af Ind X6 0 10 Af Ind X6 1 11 Af Ind X6 2 12 Af Ind X6 3 13 
programme bien type